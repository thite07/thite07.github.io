BOYFRIEND'S DAY — INSTALLABLE MOBILE WEB APP (iOS + Android)

WHAT THIS IS
A mobile-friendly Progressive Web App (PWA). It can be added to the Home Screen on iPhone and Android without paying an app-store fee.

PUBLISHING
1. Extract this ZIP.
2. Upload the entire folder (keep index.html, manifest.webmanifest, service-worker.js, and icons together) to a static host that serves the site over HTTPS.
3. Open the published HTTPS link on your phone.

INSTALL ON IPHONE
1. Open the link in Safari.
2. Tap Share.
3. Choose “Add to Home Screen”.
4. Tap Add.

INSTALL ON ANDROID
1. Open the link in Chrome.
2. Tap the three-dot menu.
3. Choose “Install app” or “Add to Home screen”.

PASSWORDS / ADMIN NOTE
In index.html, change PASSWORD and ADMIN_PASSWORD before publishing.
The current password/admin checks are client-side, so they are suitable for a personal surprise, not strong security. Edits are stored in that browser's local storage and do not automatically sync to other devices. Uploading a new version or using another device may not carry over those edits.

PHOTOS
To use your own photos, add a photos folder and update the photo placeholders in index.html to use your image filenames.
